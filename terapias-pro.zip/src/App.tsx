import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { Dashboard } from './components/dashboard/Dashboard';
import { PatientList } from './components/patients/PatientList';
import { PatientProfile } from './components/patients/PatientProfile';
import { BirthdaysView } from './components/patients/BirthdaysView';
import { AuditLogView } from './components/audit/AuditLogView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { ProfessionalsView } from './components/professionals/ProfessionalsView';
import { BackupManagerView } from './components/backup/BackupManagerView';
import { PatientFormModal } from './components/patients/PatientFormModal';
import { AnamnesisModal } from './components/anamnesis/AnamnesisModal';
import { PackageModal } from './components/packages/PackageModal';
import { SingleSessionModal } from './components/sessions/SingleSessionModal';
import { AttendanceModal } from './components/sessions/AttendanceModal';
import { WhatsAppModal } from './components/whatsapp/WhatsAppModal';
import { PublicValidationPage } from './components/public/PublicValidationPage';
import { PublicPackageValidationPage } from './components/public/PublicPackageValidationPage';
import { PackageDetailModal } from './components/packages/PackageDetailModal';
import { PackagesTrackerView } from './components/packages/PackagesTrackerView';
import { LoginView } from './components/auth/LoginView';
import {
  LayoutDashboard,
  Users,
  CalendarCheck2,
  Package,
  Menu as MenuIcon,
} from 'lucide-react';
import { Patient, User, Session, SessionPackage } from './types';
import { api } from './services/api';
import { INITIAL_PATIENTS, INITIAL_USERS, INITIAL_SESSIONS, INITIAL_PACKAGES } from './services/mockSeed';
import { useRealtimeSync } from './hooks/useRealtimeSync';

export function App() {
  const { tenant, user, switchTenant, isLoading: isAuthLoading } = useAuth();

  // Reactive URL token detection for public mobile & desktop validation
  const getPublicTokens = () => {
    if (typeof window === 'undefined') return { sessionToken: null, packageToken: null };
    const query = new URLSearchParams(window.location.search);
    const hash = window.location.hash || '';

    // Session token detection
    let sessToken = query.get('sessao') || query.get('session') || query.get('s') || query.get('token');
    if (!sessToken && hash.includes('validar-sessao=')) {
      const match = hash.split('validar-sessao=')[1];
      sessToken = match ? match.split('&')[0].split('?')[0] : null;
    }
    if (!sessToken && hash.includes('sessao=')) {
      const match = hash.split('sessao=')[1];
      sessToken = match ? match.split('&')[0].split('?')[0] : null;
    }

    // Package token detection
    let pkgToken = query.get('pacote') || query.get('package') || query.get('pkg');
    if (!pkgToken && hash.includes('validar-pacote=')) {
      const match = hash.split('validar-pacote=')[1];
      pkgToken = match ? match.split('&')[0].split('?')[0] : null;
    }
    if (!pkgToken && hash.includes('pacote=')) {
      const match = hash.split('pacote=')[1];
      pkgToken = match ? match.split('&')[0].split('?')[0] : null;
    }

    return { sessionToken: sessToken, packageToken: pkgToken };
  };

  const [tokens, setTokens] = useState(getPublicTokens);

  useEffect(() => {
    const handleUrlChange = () => {
      setTokens(getPublicTokens());
    };
    window.addEventListener('hashchange', handleUrlChange);
    window.addEventListener('popstate', handleUrlChange);
    return () => {
      window.removeEventListener('hashchange', handleUrlChange);
      window.removeEventListener('popstate', handleUrlChange);
    };
  }, []);

  const clearPublicUrl = () => {
    if (typeof window !== 'undefined') {
      window.history.replaceState(null, '', window.location.pathname);
      setTokens({ sessionToken: null, packageToken: null });
    }
  };

  // Active view state
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Shared Data States with instant initial values
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [professionals, setProfessionals] = useState<User[]>(INITIAL_USERS);
  const [sessions, setSessions] = useState<Session[]>(INITIAL_SESSIONS);
  const [packages, setPackages] = useState<SessionPackage[]>(INITIAL_PACKAGES);
  const [isLoading, setIsLoading] = useState(false);

  // Selected Entities
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedSessionForAttendance, setSelectedSessionForAttendance] = useState<Session | null>(null);
  const [selectedSessionForWhatsApp, setSelectedSessionForWhatsApp] = useState<Session | null>(null);
  const [selectedPackageDetail, setSelectedPackageDetail] = useState<SessionPackage | null>(null);

  // Modal Visibility States
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [patientToEdit, setPatientToEdit] = useState<Patient | null>(null);

  const [isAnamnesisModalOpen, setIsAnamnesisModalOpen] = useState(false);
  const [isPackageModalOpen, setIsPackageModalOpen] = useState(false);
  const [isSingleSessionModalOpen, setIsSingleSessionModalOpen] = useState(false);
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  // Load tenant data & filter according to user role and tenant
  const loadData = async () => {
    if (!tenant) return;
    try {
      const [pats, profs, sess, pkgs] = await Promise.all([
        api.getPatients(tenant.id, user),
        api.getProfessionals(tenant.id),
        api.getSessions(tenant.id),
        api.getPackages(tenant.id),
      ]);

      // Strict tenant and user-level isolation filter with graceful single-tenant fallback
      let filteredPatients = pats.filter(p => !tenant || p.tenantId === tenant.id || pats.length === 1);
      if (user && user.role === 'PROFESSIONAL' && user.accessMode === 'INDIVIDUAL') {
        filteredPatients = filteredPatients.filter(p => p.assignedProfessionalId === user.id);
      }

      let filteredSessions = sess.filter(s => !tenant || s.tenantId === tenant.id || pats.some(p => p.id === s.patientId));
      if (user && user.role === 'PROFESSIONAL' && user.accessMode === 'INDIVIDUAL') {
        filteredSessions = filteredSessions.filter(s => s.professionalId === user.id);
      }

      let filteredPackages = pkgs.filter(pkg => !tenant || pkg.tenantId === tenant.id || pats.some(p => p.id === pkg.patientId));

      setPatients(filteredPatients);
      setProfessionals(profs.filter(pr => !tenant || pr.tenantId === tenant.id || profs.length === 1));
      setSessions(filteredSessions);
      setPackages(filteredPackages);

      // If viewing a selected patient, update their reference
      if (selectedPatient) {
        const updated = filteredPatients.find(p => p.id === selectedPatient.id);
        setSelectedPatient(updated || null);
      }
    } catch (err) {
      console.warn('Erro ao carregar dados do tenant, mantendo dados locais:', err);
    }
  };

  // Real-time Centralized WebSockets/SSE sync hook
  const { status: realtimeStatus, lastSyncTime } = useRealtimeSync({
    tenantId: tenant?.id,
    onSync: () => {
      loadData();
    },
  });

  useEffect(() => {
    if (tenant && user) {
      loadData();

      // Listen for instant local updates across tabs / storage events
      const handleStorageChange = (e: StorageEvent) => {
        if (
          e.key === 'fisiopro_last_signature_sync' ||
          e.key === 'fisiopro_sessions' ||
          e.key === 'fisiopro_packages' ||
          e.key === 'fisiopro_patients' ||
          e.key?.startsWith('clinica_')
        ) {
          loadData();
        }
      };

      const handleCustomSync = () => {
        loadData();
      };

      window.addEventListener('storage', handleStorageChange);
      window.addEventListener('session-signed', handleCustomSync);

      return () => {
        window.removeEventListener('storage', handleStorageChange);
        window.removeEventListener('session-signed', handleCustomSync);
      };
    }
  }, [tenant, user]);

  // Handle Public Links (Without requiring authentication)
  if (tokens.packageToken) {
    return <PublicPackageValidationPage token={tokens.packageToken} onBackToApp={clearPublicUrl} />;
  }

  if (tokens.sessionToken) {
    return <PublicValidationPage token={tokens.sessionToken} onBackToApp={clearPublicUrl} />;
  }

  // If user is not authenticated or clinic not chosen, display Login Screen
  if (!user || !tenant) {
    return <LoginView />;
  }

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 overflow-hidden font-sans">
      {/* Dynamic Brand Sidebar */}
      <Sidebar
        activeView={activeView}
        isOpenMobile={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
        onSelectView={view => {
          setActiveView(view);
          if (view !== 'patients') {
            setSelectedPatient(null);
          }
          setIsMobileMenuOpen(false);
        }}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Header with Clinic Name, Search, & User Profile */}
        <Header
          onToggleMobileMenu={() => setIsMobileMenuOpen(prev => !prev)}
          onOpenNewPatient={() => {
            setPatientToEdit(null);
            setIsPatientModalOpen(true);
          }}
          onSelectPatient={patient => {
            setSelectedPatient(patient);
            setActiveView('patients');
          }}
          patientsList={patients}
          realtimeStatus={realtimeStatus}
          lastSyncTime={lastSyncTime}
          onManualRefresh={loadData}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto p-3.5 sm:p-5 md:p-6 lg:p-8 space-y-6 pb-24 lg:pb-8">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <>
              {/* Dashboard View */}
              {activeView === 'dashboard' && (
                <Dashboard
                  patients={patients}
                  sessions={sessions}
                  packages={packages}
                  onNavigateTab={tab => {
                    setActiveView(tab);
                    if (tab !== 'patients') setSelectedPatient(null);
                  }}
                  onSelectPatient={patient => {
                    setSelectedPatient(patient);
                    setActiveView('patients');
                  }}
                  onSendWhatsAppBirthday={patient => {
                    setSelectedPatient(patient);
                    setIsWhatsAppModalOpen(true);
                  }}
                  onOpenNewPatient={() => {
                    setPatientToEdit(null);
                    setIsPatientModalOpen(true);
                  }}
                  onOpenAnamnesis={patient => {
                    setSelectedPatient(patient);
                    setIsAnamnesisModalOpen(true);
                  }}
                  onOpenPackageModal={patient => {
                    setSelectedPatient(patient);
                    setIsPackageModalOpen(true);
                  }}
                  onOpenSingleSessionModal={patient => {
                    setSelectedPatient(patient);
                    setIsSingleSessionModalOpen(true);
                  }}
                  onAttendSession={session => {
                    setSelectedSessionForAttendance(session);
                    setIsAttendanceModalOpen(true);
                  }}
                  onSendWhatsApp={session => {
                    setSelectedSessionForWhatsApp(session);
                    setIsWhatsAppModalOpen(true);
                  }}
                />
              )}

              {/* Patients View & Detail Profiles */}
              {activeView === 'patients' && (
                <>
                  {selectedPatient ? (
                    <PatientProfile
                      patient={selectedPatient}
                      onBack={() => setSelectedPatient(null)}
                      onOpenAnamnesis={() => setIsAnamnesisModalOpen(true)}
                      onOpenPackageModal={() => setIsPackageModalOpen(true)}
                      onOpenSingleSessionModal={() => setIsSingleSessionModalOpen(true)}
                      onAttendSession={session => {
                        setSelectedSessionForAttendance(session);
                        setIsAttendanceModalOpen(true);
                      }}
                      onSendWhatsApp={session => {
                        setSelectedSessionForWhatsApp(session);
                        setIsWhatsAppModalOpen(true);
                      }}
                      onViewPackageDetail={pkg => setSelectedPackageDetail(pkg)}
                      onEditPatient={pat => {
                        setPatientToEdit(pat);
                        setIsPatientModalOpen(true);
                      }}
                      onRefreshPatient={async () => {
                        await loadData();
                      }}
                    />
                  ) : (
                    <PatientList
                      patients={patients}
                      professionals={professionals}
                      onSelectPatient={patient => setSelectedPatient(patient)}
                      onOpenCreateModal={() => {
                        setPatientToEdit(null);
                        setIsPatientModalOpen(true);
                      }}
                      onOpenEditModal={patient => {
                        setPatientToEdit(patient);
                        setIsPatientModalOpen(true);
                      }}
                      onDeletePatient={async patientId => {
                        if (window.confirm('Tem certeza que deseja excluir este paciente?')) {
                          await api.deletePatient(patientId, tenant.id);
                          await loadData();
                        }
                      }}
                    />
                  )}
                </>
              )}

              {/* Anamnesis Quick Tab */}
              {activeView === 'anamnesis' && (
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Fichas de Anamnese</h2>
                    <p className="text-sm text-slate-500 mb-6">
                      Selecione um paciente na lista abaixo para preencher ou visualizar a ficha de avaliação completa.
                    </p>
                    <PatientList
                      patients={patients}
                      professionals={professionals}
                      onSelectPatient={patient => {
                        setSelectedPatient(patient);
                        setIsAnamnesisModalOpen(true);
                      }}
                      onOpenCreateModal={() => {
                        setPatientToEdit(null);
                        setIsPatientModalOpen(true);
                      }}
                      onOpenEditModal={patient => {
                        setPatientToEdit(patient);
                        setIsPatientModalOpen(true);
                      }}
                      onDeletePatient={() => {}}
                    />
                  </div>
                </div>
              )}

              {/* Packages Tab */}
              {activeView === 'packages' && (
                <PackagesTrackerView
                  packages={packages}
                  sessions={sessions}
                  patients={patients}
                  professionals={professionals}
                  onRefreshData={loadData}
                  onOpenCreatePackage={() => {
                    setSelectedPatient(null);
                    setIsPackageModalOpen(true);
                  }}
                  onOpenAttendanceModal={session => {
                    setSelectedSessionForAttendance(session);
                    setIsAttendanceModalOpen(true);
                  }}
                  onOpenWhatsAppModal={session => {
                    setSelectedSessionForWhatsApp(session);
                    setIsWhatsAppModalOpen(true);
                  }}
                  onOpenPackageDetail={pkg => {
                    setSelectedPackageDetail(pkg);
                  }}
                />
              )}

              {/* Sessions Tab */}
              {activeView === 'sessions' && (
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                      Histórico e Agenda de Sessões
                    </h2>
                    <p className="text-sm text-slate-500 mb-4">
                      Selecione um paciente para registrar a evolução de atendimento, assinar digitalmente ou enviar lembretes.
                    </p>
                    <PatientList
                      patients={patients}
                      professionals={professionals}
                      onSelectPatient={patient => {
                        setSelectedPatient(patient);
                        setActiveView('patients');
                      }}
                      onOpenCreateModal={() => {
                        setPatientToEdit(null);
                        setIsPatientModalOpen(true);
                      }}
                      onOpenEditModal={patient => {
                        setPatientToEdit(patient);
                        setIsPatientModalOpen(true);
                      }}
                      onDeletePatient={() => {}}
                    />
                  </div>
                </div>
              )}

              {/* Birthdays Tab */}
              {activeView === 'birthdays' && (
                <BirthdaysView
                  patients={patients}
                  onSelectPatient={patient => {
                    setSelectedPatient(patient);
                    setActiveView('patients');
                  }}
                  onSendWhatsApp={patient => {
                    setSelectedPatient(patient);
                    setIsWhatsAppModalOpen(true);
                  }}
                />
              )}

              {/* Professionals & Access Control */}
              {activeView === 'professionals' && (
                <ProfessionalsView onRefreshList={loadData} />
              )}

              {/* Reports */}
              {activeView === 'reports' && (
                <ReportsView
                  patients={patients}
                  sessions={sessions}
                  packages={packages}
                  currentTenant={tenant}
                  onRefreshData={loadData}
                />
              )}

              {/* WhatsApp Automation */}
              {activeView === 'whatsapp' && (
                <WhatsAppModal
                  isOpen={true}
                  onClose={() => setActiveView('dashboard')}
                  patient={selectedPatient || patients[0]}
                  session={selectedSessionForWhatsApp || sessions[0]}
                />
              )}

              {/* Audit Logs */}
              {activeView === 'audit' && <AuditLogView />}

              {/* Database Backup & Security */}
              {activeView === 'backup' && <BackupManagerView onRefreshAllData={loadData} />}

              {/* Settings / White-label */}
              {activeView === 'settings' && <SettingsView onUpdate={loadData} onNavigateToBackup={() => setActiveView('backup')} />}
            </>
          )}
        </main>

        {/* Mobile & Tablet Bottom Navigation Bar */}
        <nav
          aria-label="Navegação móvel"
          className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-2 py-1.5 flex items-center justify-around text-[10px] font-bold shadow-2xl"
        >
          <button
            type="button"
            onClick={() => {
              setActiveView('dashboard');
              setSelectedPatient(null);
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition min-w-[54px] ${
              activeView === 'dashboard'
                ? 'text-teal-400 bg-teal-500/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 mb-0.5" />
            <span>Início</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('patients');
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition min-w-[54px] ${
              activeView === 'patients'
                ? 'text-teal-400 bg-teal-500/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4 mb-0.5" />
            <span>Pacientes</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('sessions');
              setSelectedPatient(null);
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition min-w-[54px] ${
              activeView === 'sessions'
                ? 'text-teal-400 bg-teal-500/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CalendarCheck2 className="w-4 h-4 mb-0.5" />
            <span>Sessões</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('packages');
              setSelectedPatient(null);
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition min-w-[54px] ${
              activeView === 'packages'
                ? 'text-teal-400 bg-teal-500/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Package className="w-4 h-4 mb-0.5" />
            <span>Pacotes</span>
          </button>

          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(true)}
            className="flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-slate-400 hover:text-teal-400 transition min-w-[54px]"
          >
            <MenuIcon className="w-4 h-4 mb-0.5" />
            <span>Mais</span>
          </button>
        </nav>
      </div>

      {/* MODALS */}
      {/* Patient Create / Edit Modal */}
      <PatientFormModal
        isOpen={isPatientModalOpen}
        onClose={() => {
          setIsPatientModalOpen(false);
          setPatientToEdit(null);
        }}
        professionals={professionals}
        onSave={async (patientData) => {
          const tenantId = tenant?.id || 'tenant-demo-1';
          let savedPatient: Patient;
          if (patientToEdit) {
            savedPatient = await api.updatePatient(patientToEdit.id, tenantId, patientData);
            setPatients(prev => prev.map(p => p.id === savedPatient.id ? savedPatient : p));
          } else {
            savedPatient = await api.createPatient(tenantId, patientData);
            setPatients(prev => {
              const exists = prev.some(p => p.id === savedPatient.id);
              return exists ? prev.map(p => p.id === savedPatient.id ? savedPatient : p) : [savedPatient, ...prev];
            });
          }
          if (selectedPatient && selectedPatient.id === savedPatient.id) {
            setSelectedPatient(savedPatient);
          }
          await loadData();
          setIsPatientModalOpen(false);
          setPatientToEdit(null);
        }}
        patientToEdit={patientToEdit}
      />

      {/* Anamnesis Modal */}
      {selectedPatient && (
        <AnamnesisModal
          isOpen={isAnamnesisModalOpen}
          onClose={() => setIsAnamnesisModalOpen(false)}
          patient={selectedPatient}
          onSaveAnamnesis={async (anamnesisData) => {
            if (!tenant) return;
            await api.saveAnamnesis(selectedPatient.id, tenant.id, anamnesisData);
            await loadData();
            setIsAnamnesisModalOpen(false);
          }}
        />
      )}

      {/* Create Package Modal */}
      <PackageModal
        isOpen={isPackageModalOpen}
        onClose={() => {
          setIsPackageModalOpen(false);
          setSelectedPatient(null);
        }}
        patients={patients}
        professionals={professionals}
        preselectedPatientId={selectedPatient?.id}
        onSavePackage={async (pkgData) => {
          if (!tenant) return;
          await api.createPackage(tenant.id, pkgData);
          await loadData();
          setIsPackageModalOpen(false);
          setSelectedPatient(null);
        }}
      />

      {/* Create Single Session Modal */}
      <SingleSessionModal
        isOpen={isSingleSessionModalOpen}
        onClose={() => {
          setIsSingleSessionModalOpen(false);
          setSelectedPatient(null);
        }}
        patients={patients}
        professionals={professionals}
        preselectedPatientId={selectedPatient?.id}
        onSessionCreated={async () => {
          await loadData();
          setIsSingleSessionModalOpen(false);
          setSelectedPatient(null);
        }}
      />

      {/* Attend Session Modal */}
      {selectedSessionForAttendance && (
        <AttendanceModal
          isOpen={isAttendanceModalOpen}
          onClose={() => {
            setIsAttendanceModalOpen(false);
            setSelectedSessionForAttendance(null);
          }}
          session={selectedSessionForAttendance}
          onSave={async () => {
            await loadData();
            setIsAttendanceModalOpen(false);
            setSelectedSessionForAttendance(null);
          }}
        />
      )}

      {/* WhatsApp Message Modal */}
      {isWhatsAppModalOpen && (
        <WhatsAppModal
          isOpen={isWhatsAppModalOpen}
          onClose={() => {
            setIsWhatsAppModalOpen(false);
            setSelectedSessionForWhatsApp(null);
          }}
          patient={selectedPatient || patients[0]}
          session={selectedSessionForWhatsApp || undefined}
        />
      )}

      {/* Package Detail Modal */}
      {selectedPackageDetail && (
        <PackageDetailModal
          isOpen={!!selectedPackageDetail}
          onClose={() => setSelectedPackageDetail(null)}
          pkg={selectedPackageDetail}
          sessions={sessions.filter(s => s.packageId === selectedPackageDetail.id)}
          onAttendSession={session => {
            setSelectedPackageDetail(null);
            setSelectedSessionForAttendance(session);
            setIsAttendanceModalOpen(true);
          }}
          onSendWhatsApp={session => {
            setSelectedPackageDetail(null);
            setSelectedSessionForWhatsApp(session);
            setIsWhatsAppModalOpen(true);
          }}
          onRefresh={loadData}
        />
      )}
    </div>
  );
}

export default App;
