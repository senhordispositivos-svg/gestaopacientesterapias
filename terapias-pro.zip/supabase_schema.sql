-- =========================================================
-- SCHEMA COMPLETO FISIOPRO PARA SUPABASE (POSTGRESQL)
-- =========================================================

CREATE TABLE IF NOT EXISTS tenants (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  trade_name TEXT,
  corporate_name TEXT,
  doc_type TEXT,
  document_number TEXT,
  email TEXT,
  phone TEXT,
  cep TEXT,
  address TEXT,
  number TEXT,
  complement TEXT,
  neighborhood TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  logo_url TEXT,
  primary_color TEXT,
  secondary_color TEXT,
  theme_mode TEXT,
  custom_header TEXT,
  public_page_title TEXT,
  support_email TEXT,
  support_phone TEXT,
  creator_name TEXT,
  whatsapp_config JSONB,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL,
  access_mode TEXT NOT NULL,
  specialty TEXT,
  council_type TEXT,
  council_number TEXT,
  phone TEXT,
  active BOOLEAN DEFAULT TRUE NOT NULL,
  avatar_url TEXT,
  is_super_user BOOLEAN DEFAULT FALSE,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  cpf TEXT,
  rg TEXT,
  gender TEXT,
  phone TEXT NOT NULL,
  whatsapp TEXT,
  profession TEXT,
  birth_date TEXT,
  cep TEXT,
  street TEXT,
  number TEXT,
  complement TEXT,
  neighborhood TEXT,
  city TEXT,
  state TEXT,
  reference_point TEXT,
  notes TEXT,
  photo_url TEXT,
  avatar_url TEXT,
  assigned_professional_id TEXT,
  assigned_professional_name TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS anamneses (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  health_history JSONB,
  treatments JSONB,
  habits JSONB,
  evaluation JSONB,
  responsibility_term_accepted BOOLEAN,
  patient_signature_url TEXT,
  city TEXT,
  state TEXT,
  signed_at TEXT,
  signed_by_ip TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS packages (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  professional_id TEXT,
  professional_name TEXT,
  title TEXT NOT NULL,
  treatment_type TEXT,
  session_count INTEGER NOT NULL,
  completed_count INTEGER NOT NULL,
  price INTEGER NOT NULL,
  validity_date TEXT,
  status TEXT NOT NULL,
  client_signature_url TEXT,
  client_confirmed_at TEXT,
  signed_term_url TEXT,
  signed_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  package_id TEXT REFERENCES packages(id) ON DELETE SET NULL,
  is_single_session BOOLEAN,
  price INTEGER,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  patient_name TEXT NOT NULL,
  professional_id TEXT NOT NULL,
  professional_name TEXT NOT NULL,
  session_number INTEGER NOT NULL,
  scheduled_date TEXT NOT NULL,
  scheduled_time TEXT NOT NULL,
  status TEXT NOT NULL,
  blood_pressure TEXT,
  si_notes TEXT,
  procedures JSONB,
  evolution_text TEXT,
  attended_at TEXT,
  client_signature_url TEXT,
  client_confirmed_at TEXT,
  client_confirmed_ip TEXT,
  validation_token TEXT,
  token_expires_at TEXT,
  token_used_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS evolutions (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  session_id TEXT REFERENCES sessions(id) ON DELETE SET NULL,
  professional_id TEXT,
  professional_name TEXT,
  date TEXT NOT NULL,
  procedures JSONB,
  notes TEXT NOT NULL,
  blood_pressure TEXT,
  version INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public_tokens (
  id TEXT PRIMARY KEY,
  token TEXT NOT NULL,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  user_role TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  ip_address TEXT,
  result TEXT,
  details TEXT NOT NULL,
  timestamp TEXT
);

CREATE TABLE IF NOT EXISTS document_files (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  uploaded_by_user_id TEXT,
  uploaded_by_name TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  file_url TEXT NOT NULL,
  category TEXT NOT NULL,
  notes TEXT,
  uploaded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS signatures (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  patient_name TEXT,
  document_type TEXT NOT NULL,
  document_id TEXT,
  reference_id TEXT,
  signature_url TEXT NOT NULL,
  signed_by_name TEXT,
  signed_at TEXT NOT NULL,
  ip_address TEXT NOT NULL,
  hash TEXT NOT NULL
);

-- Inserção de registro padrão inicial da clínica e dos usuários administradores
INSERT INTO tenants (id, name, trade_name, corporate_name, doc_type, document_number, email, phone, city, state, created_at)
VALUES (
  'tenant-demo-1',
  'Clínica de Terapias Integradas',
  'Clínica Fisio & Terapia Integrada',
  'Fisio & Terapia Integrada LTDA',
  'CNPJ',
  '12.345.678/0001-90',
  'contato@fisioterapia.com.br',
  '(11) 99999-8888',
  'São Paulo',
  'SP',
  NOW()::TEXT
) ON CONFLICT (id) DO NOTHING;

INSERT INTO users (id, tenant_id, name, email, role, access_mode, active, is_super_user, created_at)
VALUES 
  ('user-master-1', 'tenant-demo-1', 'osaiasbrito', 'osaiasbrito@gmail.com', 'ADMIN', 'FULL', true, true, NOW()::TEXT),
  ('user-master-2', 'tenant-demo-1', 'senhordispositivos', 'senhordispositivos@gmail.com', 'ADMIN', 'FULL', true, true, NOW()::TEXT)
ON CONFLICT (id) DO NOTHING;
